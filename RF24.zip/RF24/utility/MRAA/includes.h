  
#ifndef __RF24_INCLUDES_H__
#define __RF24_INCLUDES_H__

  #ifndef MRAA
  	  #define MRAA
  #endif
  #include "MRAA/RF24_arch_config.h"
   
  
#endif
